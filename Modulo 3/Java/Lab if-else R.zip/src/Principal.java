
public class Principal {

	public static void main(String[] args) {
		String usuario = "usuario";
		String clave = "clave";

		if (usuario.equals("usuario") && clave.equals("clave")) {
			System.out.println("Bienvenido al sistema...");
		} else {

			System.out.println("Credenciales Incorrectas");
		}
	}

}
